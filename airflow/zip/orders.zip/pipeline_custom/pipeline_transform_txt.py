from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep
from pyspark.sql.functions import when

class PipelineTransformTxt(PipelineStep):
    def __init__(self):
        super().__init__()
        print('transform data')

    def run(self, spark, params, df):
        # drop_cols = ['_c0', 'german_name', 'japanese_name', 'species','ability_1','ability_2','ability_hidden','total_points','hp','attack','defense','sp_attack','sp_defense','speed','catch_rate','base_friendship','base_experience','growth_rate','egg_type_number','egg_type_1','egg_type_2','percentage_male','egg_cycles','against_normal','against_fire','against_water','against_electric','against_grass','against_ice','against_fight','against_poison','against_ground','against_flying','against_psychic','against_bug','against_rock','against_ghost','against_dragon','against_dark','against_steel']
        # df = df.withColumn("type_2", when(df.type_2 != "Null", df.type_2).otherwise(df.type_1))
        df = df.withColumn('unitPrice',  df.price / df.quantity )
        # df = df.withColumn('fullDate', df.order_date+'T' + df.order_time )
        drop_cols = ['team_code','description', 'TS_id', 'order_id','player_name', 'player_number','order_time']
        df = df.drop(*drop_cols)
        
        # team_code,order_date,order_time,TS_id,order_id,quantity,description,buyerMode,jersey_size,player_name,player_number,player_option,price,status

        return df