from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep
from pyspark.sql.functions import when

class PipelineTransformTxt(PipelineStep):
    def __init__(self):
        super().__init__()
        print('transform data')

    def run(self, spark, params, df):
        drop_cols = ['_c0', 'german_name', 'japanese_name', 'species']
        df = df.drop(*drop_cols)
        df = df.withColumn("type_2", when(df.type_2 != "Null", df.type_2).otherwise(df.type_1))
        #df = df.withColumn('source', f.lit('wcd'))
        return df