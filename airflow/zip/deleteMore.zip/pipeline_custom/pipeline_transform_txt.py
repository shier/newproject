from pyspark.sql import functions as f
from pipeline_step.pipeline_step import PipelineStep
from pyspark.sql.functions import when

class PipelineTransformTxt(PipelineStep):
    def __init__(self):
        super().__init__()
        print('transform data')

    def run(self, spark, params, df):
        #drop_cols = ['descrption', 'tsID', 'orderID', 'unitPrice']
        drop_cols = ['_c0', 'german_name', 'japanese_name', 'species','ability_1','ability_2','ability_hidden','total_points','hp','attack','defense','sp_attack','sp_defense','speed','catch_rate','base_friendship','base_experience','growth_rate','egg_type_number','egg_type_1','egg_type_2','percentage_male','egg_cycles','against_normal','against_fire','against_water','against_electric','against_grass','against_ice','against_fight','against_poison','against_ground','against_flying','against_psychic','against_bug','against_rock','against_ghost','against_dragon','against_dark','against_steel']
        df = df.drop(*drop_cols)
        df = df.withColumn("type_2", when(df.type_2 != "Null", df.type_2).otherwise(df.type_1))
        df = df.withColumn('source', f.lit('wcd'))
        return df